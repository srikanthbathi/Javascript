export class UserBilling {
	public id: number;
	public userBillingName: string;
	public userBillingStreet1: string;
	public userBillingStreet2: string;
	public userBillingCity: string;
	public userBillingState: string;
	public userBillingCountry: string;
	public userBillingZipcode: string;

}
