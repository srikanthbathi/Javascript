import {User} from './user';

export class ShoppingCart {
	public id: number;
	public grandTotal: number;
	public user: User;
}
